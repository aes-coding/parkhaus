
public class Ticket
{
    private int ticketid;
    private DateTime erstellzeitpunkt;
    private boolean istbezahlt;
    public Ticket()
    {
        ticketid = 1;
        istbezahlt = false;
    }
}
