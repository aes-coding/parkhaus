
public class Kassenautomat
{
    private double anzeigeParkgebuehr;
    private double anzeigeGeldeingabe;
    public Kassenautomat()
    {
        anzeigeParkgebuehr = 0;
        anzeigeGeldeingabe = 0;
    }
    
    public void bezahleTicket(int ticketid){
        
    }
}
