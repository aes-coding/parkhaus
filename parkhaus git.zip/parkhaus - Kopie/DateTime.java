
public class DateTime
{
    
    public DateTime()
    {
        DateTime date = null;
    }
    public DateTime now(){
        return date;
    }
    public boolean equals(DateTime date){
        
    }
    public boolean isBefore(DateTime date){
        
    }
    public boolean isAfter(DateTime date){
        
    }
    public DateTime plusMinutes(long minutes){
        
    }
    public String toString(){
        
    }
}
