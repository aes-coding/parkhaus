
public class Ausfahrt
{
    private boolean ticketEingefuehrt;
   
    public Ausfahrt()
    {
        ticketEingefuehrt = false;
    }
    
    public void eingabeTicket(int tickedid){
        
    }
    
    public void rueckgabeTicket(){
        
    }
    
    public void oeffneSchranke(){
        
    }
}
