
public class Einfahrt
{
    private boolean ticketAngefordert;
    private boolean ticketEntnommen;
    public Einfahrt()
    {
        ticketAngefordert = false;
        ticketEntnommen = false;
    }
    
    public void anforderungTicket(){
        
    }
    
    public void druckeTicket(int ticket){
        
    }
    
    public void entnahmeTicket(){
        
    }
    
    public void oeffneSchranke(){
        
    }
}
